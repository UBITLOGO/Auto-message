
import os, datetime as dt
from dotenv import load_dotenv
from sqlalchemy import create_engine, Column, Integer, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes

BASE_DIR = os.path.dirname(__file__)
load_dotenv(os.path.join(BASE_DIR, ".env"))

BOT_TOKEN = os.getenv("BOT_TOKEN","")
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME","")
AGENCY_NAME = os.getenv("AGENCY_NAME","Crypto Listing Hub")
WEBSITE = os.getenv("WEBSITE","")
TELEGRAM_GROUP = os.getenv("TELEGRAM_GROUP","")

if not BOT_TOKEN:
    raise SystemExit("Set BOT_TOKEN in .env")

# ---- DB (SQLite) to store first-contact state ----
engine = create_engine(f"sqlite:///{os.path.join(BASE_DIR, 'contacts.db')}", echo=False, future=True)
Base = declarative_base()
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)

class SeenUser(Base):
    __tablename__ = "seen_users"
    user_id = Column(Integer, primary_key=True)
    first_seen = Column(DateTime, nullable=False, default=dt.datetime.utcnow)

Base.metadata.create_all(engine)

def is_first_time(user_id: int) -> bool:
    with SessionLocal() as db:
        row = db.get(SeenUser, user_id)
        if row is None:
            db.add(SeenUser(user_id=user_id, first_seen=dt.datetime.utcnow()))
            db.commit()
            return True
        return False

def load_text(path: str) -> str:
    with open(os.path.join(BASE_DIR, path), "r", encoding="utf-8") as f:
        return f.read()

FIRST_CONTACT_TEXT = load_text("first_contact_message.txt")
SERVICES_TEXT = load_text("services.txt")

def format_text(t: str) -> str:
    return (t
        .replace("{AGENCY_NAME}", AGENCY_NAME)
        .replace("{WEBSITE}", WEBSITE)
        .replace("{TELEGRAM_GROUP}", TELEGRAM_GROUP)
        .replace("{ADMIN_USERNAME}", ADMIN_USERNAME)
    )

def main_menu_kb():
    btns = [
        [InlineKeyboardButton("📋 Services", callback_data="services"),
         InlineKeyboardButton("📞 Contact", url=f"https://t.me/{ADMIN_USERNAME}")],
        [InlineKeyboardButton("🌐 Website", url=WEBSITE if WEBSITE else "https://t.me")]
    ]
    return InlineKeyboardMarkup(btns)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        f"Hi! This is {AGENCY_NAME}. Send any message to begin.", reply_markup=main_menu_kb()
    )

async def on_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.effective_user or not update.effective_chat:
        return
    uid = update.effective_user.id
    txt = (update.message.text or "").strip().lower()

    # If they type SERVICES anytime
    if "services" in txt:
        await update.message.reply_text(SERVICES_TEXT, reply_markup=main_menu_kb())
        return

    # First contact auto-reply
    if is_first_time(uid):
        await update.message.reply_text(format_text(FIRST_CONTACT_TEXT), reply_markup=main_menu_kb())
    else:
        # Subsequent replies (lightweight)
        await update.message.reply_text(
            "Thanks! Our team will get back to you soon. Type *SERVICES* to view our offerings.",
            reply_markup=main_menu_kb(),
            parse_mode="Markdown"
        )

async def on_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not q:
        return
    data = q.data or ""
    if data == "services":
        await q.answer()
        await q.message.reply_text(SERVICES_TEXT, reply_markup=main_menu_kb())

def run():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.ALL & ~filters.COMMAND, on_message))
    app.add_handler(MessageHandler(filters.COMMAND, start))
    from telegram.ext import CallbackQueryHandler
    app.add_handler(CallbackQueryHandler(on_callback))
    app.run_polling()

if __name__ == "__main__":
    run()
