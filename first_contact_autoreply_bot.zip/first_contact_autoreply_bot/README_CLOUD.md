# Cloud Deploy (No Laptop Needed)

You can host this bot 24/7 using Render or Railway (free/low-cost).

## Option A: Render (Worker)
1) Create an account at render.com
2) New -> **Blueprint** -> connect a repo with these files (or upload via private Git).
3) In the repo root, keep `render.yaml`. Render will create a **Worker**.
4) Set Environment Variables in Render dashboard:
   - `BOT_TOKEN` (from @BotFather)
   - `ADMIN_USERNAME` (without @)
   - `AGENCY_NAME` (optional, default: Crypto Listing Hub)
   - `WEBSITE` (optional)
   - `TELEGRAM_GROUP` (optional)
5) Deploy. The worker will start `python bot.py` and run 24/7.

## Option B: Railway
1) Create an account at railway.app
2) New Project -> Deploy from Repo or Upload, include `railway.json` and the code.
3) Set Environment Variables:
   - `BOT_TOKEN`, `ADMIN_USERNAME`, `AGENCY_NAME`, `WEBSITE`, `TELEGRAM_GROUP`
4) Deploy. Service runs `python bot.py` continuously.

## Option C: Docker (Any VPS)
1) `docker build -t first-contact-bot .`
2) `docker run -e BOT_TOKEN=XXX -e ADMIN_USERNAME=youruser -e AGENCY_NAME="Crypto Listing Hub" -e WEBSITE="https://..." -e TELEGRAM_GROUP="https://t.me/..." first-contact-bot`
